Author : Akash Khandelwal
========================================================================================================================
Note:- In order to run this Alexa.py make sure that you have all this dependcies in your Computer
>Python "You can easily download from Python.org"
this library must in your computer otherwise you got an error
>wikipedia
>webbrowser
>pygame
>pyautogui
>os
>speech recongition
>pysstx3
>request
>pyjokes
>wolframalpha
>opencv
Easily download this Library from command line 
step 1:open commandline
step 2:pip install "library name" ex:-pip install pygame
=========================================================================================================================
>Made Virtual Desktop voice based Assistant using Python named "Alexa"
>Add Music Files "demo.mpeg" using Pygame library of python by mixer module
>Python file and music file("demo.mpeg") should be in same directory otherwise you got an error
>The program have an User Authentication system here i use getpass library of python for Invisible password
*Password : - akash2600
>Used WolframAlpha Api in this Assistant for any type calculation we want then we do it.Using WolframAplha key
from WolframAlpha website
>Used OpenWeatherAPI from OpenWeatherAPI website(used Request module of Python) 
>Used NewsAPI from NewsAPI website(used Request module of Python)
>Used wikipedia library for any type of information we wants to know from wikipedia we easily do it.
